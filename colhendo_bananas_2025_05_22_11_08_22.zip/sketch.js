let bananas = [];
let score = 0;
let treeX, treeY;

function setup() {
  createCanvas(600, 400);
  // Posição da árvore
  treeX = width / 2;
  treeY = height - 100;
  // Cria algumas bananas inicialmente
  for (let i = 0; i < 5; i++) {
    bananas.push(new Banana(random(treeX - 50, treeX + 50), random(treeY - 150, treeY - 50)));
  }
}

function draw() {
  background(135, 206, 235); // Céu azul
  drawGround();
  drawSun();
  drawTree();
  displayScore();

  // Atualiza e mostra as bananas
  for (let i = bananas.length - 1; i >= 0; i--) {
    bananas[i].show();
    if (bananas[i].isCollected(mouseX, mouseY)) {
      bananas.splice(i, 1);
      score++;
      // Opcional: criar uma nova banana
      bananas.push(new Banana(random(treeX - 50, treeX + 50), random(treeY - 150, treeY - 50)));
    }
  }
}

// Função para desenhar o chão
function drawGround() {
  fill(34, 139, 34); // Verde
  rect(0, height - 50, width, 50);
}

// Função para desenhar o sol
function drawSun() {
  fill(255, 204, 0);
  ellipse(80, 80, 60, 60);
}

// Função para desenhar a árvore
function drawTree() {
  // Tronco
  fill(139, 69, 19);
  rect(treeX - 15, treeY, 30, 100);
  // Folhagem
  fill(34, 139, 34);
  ellipse(treeX, treeY - 50, 150, 150);
  // Desenhar bananas na árvore
  fill(255, 255, 0);
  for (let i = 0; i < 8; i++) {
    let angle = TWO_PI / 8 * i;
    let bx = treeX + cos(angle) * 60;
    let by = treeY - 50 + sin(angle) * 60;
    ellipse(bx, by, 10, 20);
  }
}

// Função para mostrar a pontuação
function displayScore() {
  fill(0);
  textSize(24);
  text("Pontuação: " + score, 20, 30);
}

// Classe Banana
class Banana {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 20;
  }

  show() {
    fill(255, 255, 0);
    ellipse(this.x, this.y, this.size, this.size * 1.5);
  }

  isCollected(mx, my) {
    let d = dist(mx, my, this.x, this.y);
    return d < this.size;
  }
}